# kwb.event

[![Build status](https://ci.appveyor.com/api/projects/status/6pixu5j1qd113wqa/branch/master?svg=true)](https://ci.appveyor.com/project/KWB-R/kwb-event/branch/master)
[![Build Status](https://travis-ci.org/KWB-R/kwb.event.svg?branch=master)](https://travis-ci.org/KWB-R/kwb.event)
[![codecov](https://codecov.io/github/KWB-R/kwb.event/branch/master/graphs/badge.svg)](https://codecov.io/github/KWB-R/kwb.event)
[![lifecycle](https://img.shields.io/badge/lifecycle-stable-brightgreen.svg)](https://www.tidyverse.org/lifecycle/#stable)
[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/kwb.event)](http://cran.r-project.org/package=kwb.event)


Generate Events from Time Series and work with Events
