# kwb.datetime

[![Appveyor build status](https://ci.appveyor.com/api/projects/status/eby9o2bq57y9g0x9/branch/master?svg=true)](https://ci.appveyor.com/project/KWB-R/kwb-datetime/branch/master)
[![Build Status](https://travis-ci.org/KWB-R/kwb.datetime.svg?branch=master)](https://travis-ci.org/KWB-R/kwb.datetime)
[![codecov](https://codecov.io/github/KWB-R/kwb.datetime/branch/master/graphs/badge.svg)](https://codecov.io/github/KWB-R/kwb.datetime)
[![lifecycle](https://img.shields.io/badge/lifecycle-stable-brightgreen.svg)](https://www.tidyverse.org/lifecycle/#stable)
[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/kwb.datetime)](http://cran.r-project.org/package=kwb.datetime)

R Package with Functions for Date Time Handling

## Documentation

Development version: [https://kwb-r.github.io/kwb.datetime/dev](https://kwb-r.github.io/kwb.datetime/dev)
Latest release: [https://kwb-r.github.io/kwb.datetime](https://kwb-r.github.io/kwb.datetime)
