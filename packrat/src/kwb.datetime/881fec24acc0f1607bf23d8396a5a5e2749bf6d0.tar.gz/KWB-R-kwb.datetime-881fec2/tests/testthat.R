library(testthat)
library(kwb.datetime)

test_check("kwb.datetime")
