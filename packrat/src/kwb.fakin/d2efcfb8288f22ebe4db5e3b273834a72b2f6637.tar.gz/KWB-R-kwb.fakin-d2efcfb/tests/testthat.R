library("testthat")
library("kwb.fakin")

test_check("kwb.fakin")
