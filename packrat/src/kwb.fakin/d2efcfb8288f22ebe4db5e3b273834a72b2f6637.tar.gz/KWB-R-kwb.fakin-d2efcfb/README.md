# kwb.fakin

[![Appveyor build status](https://ci.appveyor.com/api/projects/status/18p0ui3jcdm5lqw9/branch/master?svg=true)](https://ci.appveyor.com/project/KWB-R/kwb-fakin/branch/master)
[![Build Status](https://travis-ci.org/KWB-R/kwb.fakin.svg?branch=master)](https://travis-ci.org/KWB-R/kwb.fakin)
[![codecov](https://codecov.io/github/KWB-R/kwb.fakin/branch/master/graphs/badge.svg)](https://codecov.io/github/KWB-R/kwb.fakin)
[![lifecycle](https://img.shields.io/badge/lifecycle-stable-brightgreen.svg)](https://www.tidyverse.org/lifecycle/#stable)
[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/kwb.fakin)](http://cran.r-project.org/package=kwb.fakin)

Functions Used in Our Fakin Project
