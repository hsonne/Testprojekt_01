# kwb.plot

[![Appveyor build status](https://ci.appveyor.com/api/projects/status/ljocere3ptnxw589/branch/master?svg=true)](https://ci.appveyor.com/project/KWB-R/kwb-plot/branch/master)
[![Build Status](https://travis-ci.org/KWB-R/kwb.plot.svg?branch=master)](https://travis-ci.org/KWB-R/kwb.plot)
[![codecov](https://codecov.io/github/KWB-R/kwb.plot/branch/master/graphs/badge.svg)](https://codecov.io/github/KWB-R/kwb.plot)
[![lifecycle](https://img.shields.io/badge/lifecycle-stable-brightgreen.svg)](https://www.tidyverse.org/lifecycle/#stable)
[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/kwb.plot)](http://cran.r-project.org/package=kwb.plot)

R Package Containing Helper Functions for Plotting