library(testthat)
library(kwb.plot)

test_check("kwb.plot")
